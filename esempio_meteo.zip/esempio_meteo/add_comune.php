<?php
require_once './config.php';
require_once './database/database.php';
?>
  <!DOCTYPE html>
  <html lang="it">
  <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" type="text/css" href="./styles/style.css">
      <title>Aggiungi comune</title>
      <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
                  }

                  .container {
                      max-width: 800px;
                      margin: 0 auto;
                      padding: 20px;
                  }

                  h1 {
                      text-align: center;
                  }
          .link-column {
              text-align: center;
          }

          .link-column a {
              display: inline-block;
              padding: 5px 10px;
              background-color: #3498db;
              color: #fff;
              text-decoration: none;
              border-radius: 3px;
          }

          .form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

select {
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
  width: 100%;
  transition: border-color 0.3s ease;
}

select:focus {
  border-color: #888;
}

button[type="submit"] {
  padding: 10px 20px;
  font-size: 16px;
  color: #fff;
  background-color: #007bff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
  background-color: #0056b3;
}

      </style>
  </head>
  <body>
      <div class="container">
          <h1>Inserisci comune</h1>
          <center><a href="./HomePage.php" class="btn">BACK TO HOME</a></center>
          <?php
          if(isset($_POST["Nome"]) && $_SERVER['REQUEST_METHOD'] === 'POST'){
            //creo un array associativo con tutti i valori che ho passato dal form riprelevati in POST
            //i nomi dell'array associativo potrebbero anche essere diversi
            $com = array(
                "Nome"       =>    $_REQUEST["Nome"],
                "provincia"  =>    $_REQUEST["dropdown"],
                "lat"        =>    $_REQUEST["Lat"],
                "long"        =>    $_REQUEST["Long"],
                "Id_comune"   =>   $_REQUEST["Id_comune"]
            );
            $conn = openconnection();
            $sql = "SELECT * FROM comuni c WHERE c.Id='".$com["Id_comune"]."'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
              $message_add="Id comune esistente";
            }
            else{
              //Attenzione ai valori numerici ed ai valori stringa!!
              //Verifica per capire la differenza
              //(apice si per le stringhe, apice no per gli interi o i campi chiave)
              $sql="INSERT INTO comuni (Id,Nome, Longitudine, Latitudine, ID_Provincia)
              VALUES ('".$com["Id_comune"]."',
                      '".$com["Nome"]."',
                      ".$com["long"].",
                      ".$com["lat"].",
                      '".$com["provincia"]."'
              )";
              $result = $conn->query($sql);
              if ($result==TRUE){
                $message_add="Comune inserito";
              }
              else{
                $message_add="Errore del Server: Comune non inserito";
              }
              closeconnection($conn);
            }
            if(isset($message_add)){
              echo "<p>$message_add</p>";
            }
          }
          ?>
          <form href="" method="POST">
            <label for='Id_comune'>ID comune</label>
            <input type="text" maxlength="40" name="Id_comune" id="Id_comune" required/>
            <label for='Nome'>Nome comune</label>
            <input type="text" name="Nome" id="Nome" required/>
            <?php
              $conn = openconnection();
              $sql = "SELECT Id,Nome FROM province";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) {
                echo "<label for='dropdown'>Select an option:</label>";
                echo "<select name='dropdown' id='dropdown'>";
                while ($row = $result->fetch_assoc()) {
                  $nome = $row["Nome"];
                  $id=$row["Id"];
                  echo "<option value='$id'>$nome</option>";
                }
                echo "</select>";
              }
              else{
                echo "Server error";
              }
              closeconnection($conn);
            ?>
            <label for='Long'>Longitudine: </label>
            <input type="number" step="0.1" name="Long" id="Long" required/>
            <label for='Lat'>Latitudine: </label>
            <input type="number" step="0.1" name="Lat" id="Lat" required/>
            <input type="submit" value="INSERISCI COMUNE">
          </form>
      </div>
      <?php include './footer.php'; ?>
  </body>
  </html>
