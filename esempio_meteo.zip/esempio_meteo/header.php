<header>
    <nav class="navbar">
        <div class="container">
             <a href="./HomePage.php" class="logo"><img src="./images/logo.jpeg" alt="Logo"></a>
            <ul class="nav-links">
                <li><a href="./HomePage.php">HomePage</a></li>
                <li><a href="./lista_comuni.php">Lista comuni</a></li>
                <li><a href="./add_comune.php">Aggiungi comune</a></li>
                <li><a href="./all_data.php">Dati</a></li>
            </ul>
        </div>
    </nav>
</header>
