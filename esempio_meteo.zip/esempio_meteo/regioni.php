<?php
require_once './config.php';
require_once './database/database.php';
?>
  <!DOCTYPE html>
  <html lang="it">
  <head>
    <meta charset="UTF-8">
    <!--Importo il file css (External css) -->
    <link rel="stylesheet" type="text/css" href="./styles/style.css">
    <title>Regioni</title>
    <!-- Internal css -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
                  }

                  .container {
                      max-width: 800px;
                      margin: 0 auto;
                      padding: 20px;
                  }
                  /*
                   i bordi delle celle si uniscono in un unico bordo tra le celle adiacenti.
                   Ciò significa che non ci saranno spazi o divisioni visibili tra i bordi delle celle.
                  */
                  table {
                      width: 100%;
                      border-collapse: collapse;
                      margin-bottom: 20px;
                  }

                  table th,
                  table td {
                      padding: 10px;
                      text-align: left;
                      /* Definisco stile bordo inferiore
                      spessore , solid indica linea continua, colore in esadecimale */
                      border-bottom: 1px solid #ddd;
                  }

                  table th {
                      background-color: #f2f2f2;
                  }

                  h1 {
                      text-align: center;
                  }
          .link-column {
              text-align: center;
          }

          .link-column a {
              display: inline-block;
              padding: 5px 10px;
              background-color: #3498db;
              color: #fff;
              text-decoration: none;
              border-radius: 3px;
          }
      </style>
  </head>
  <body>
    <div class="container">
      <h1>Regioni trovate</h1>
      <center><a href="./HomePage.php" class="btn">BACK TO HOME</a></center>
      <?php
        // Apro la connessione al database
        $conn = openconnection();

        // Controllo se è stato ricevuto un ID in GET
        if (isset($_GET['id'])) {
          // Prendo l'ID dalla query in GET
          $id = $_GET['id'];

          // Preparo la query
          $sql = "SELECT Id,Nome FROM regioni WHERE ID_AreaTerritoriale = '$id'";

          // Eseguo la query
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
            echo "<table>
                  <tr>
                  <th>Nome</th>
                  <th>Azione</th>
                  </tr>";

            // Itero sui risultati della query
            while ($row = $result->fetch_assoc()) {
              $nome = $row["Nome"];
              $id_reg=$row["Id"];
              echo "<tr>
                      <td>$nome</td>
                      <td class='link-column'>
                      <a href='province.php?id=$id_reg'>Dettagli</a>
                      </td>
                    </tr>";
            }

            echo "</table>";
          } else {
            echo "Nessun risultato trovato.";
                  }
          } else {
            echo "ID non specificato.";
            }

              // Chiudo la connessione al database
          closeconnection($conn);
        ?>
      </div>
  <?php include './footer.php'; ?>
  </body>
  </html>
