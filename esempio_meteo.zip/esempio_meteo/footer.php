<footer>
    <div class="footer-content">
        <div class="container">
            <div class="footer-logo">

                <img src="./images/logo.jpeg" alt="Logo">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="about.html">Chi siamo</a></li>
                    <li><a href="services.html">Servizi</a></li>
                    <li><a href="contact.html">Contatti</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p>Tutti i diritti riservati &copy; 2023</p>
        </div>
    </div>
</footer>
