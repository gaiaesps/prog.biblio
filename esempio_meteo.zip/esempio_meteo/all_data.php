<?php
require_once './config.php';
require_once './database/database.php';
?>
  <!DOCTYPE html>
  <html lang="it">
  <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" type="text/css" href="./styles/style.css">
      <title>Comuni</title>
      <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
                  }

                  .container {
                      max-width: 800px;
                      margin: 0 auto;
                      padding: 20px;
                  }

                  table {
                      width: 100%;
                      border-collapse: collapse;
                      margin-bottom: 20px;
                  }

                  table th,
                  table td {
                      padding: 10px;
                      text-align: left;
                      border-bottom: 1px solid #ddd;
                  }

                  table th {
                      background-color: #f2f2f2;
                  }

                  h1 {
                      text-align: center;
                  }
          .link-column {
              text-align: center;
          }

          .link-column a {
              display: inline-block;
              padding: 5px 10px;
              background-color: #3498db;
              color: #fff;
              text-decoration: none;
              border-radius: 3px;
          }
      </style>
  </head>
  <body>
      <div class="container">
          <h1>Comuni trovati</h1>
          <center><a href="./HomePage.php" class="btn">BACK TO HOME</a></center>
          <div>
            <form action="" method="POST">
              <input type="text" name="comune" placeholder="cerca comune" />
              <input type="submit" value="FILTRA" />
            </form>
          </div>
          <?php
              // Apro la connessione al database
              $conn = openconnection();

              if(isset($_POST["comune"]) && $_SERVER['REQUEST_METHOD'] === 'POST'){
                $comune=$_POST['comune'];
                $sql="SELECT c.Id,c.Nome, t.Minima, t.Massima, t.Data
                      FROM comuni AS c
                      JOIN temperature AS t ON c.Id = t.ID_Comune
                      WHERE c.Nome='$comune' LIMIT 5000";
              }
              else{
                $sql="SELECT c.Id,c.Nome, t.Minima, t.Massima, t.Data
                      FROM comuni AS c
                      JOIN temperature AS t ON c.Id = t.ID_Comune LIMIT 5000";
              }
              $result = $conn->query($sql);

              if($result->num_rows > 0){
                 echo "<table>
                      <tr>
                          <th>Nome</th>
                          <th>Temperatura minima</th>
                          <th>Temperatura massima</th>
                          <th>Data</th>
                      </tr>";

                while ($row = $result->fetch_assoc()) {
                          $nome = $row["Nome"];
                          $minima=$row["Minima"];
                          $massima=$row["Massima"];
                          $data = $row["Data"];
                          echo "<tr>
                                  <td>$nome</td>
                                  <td>$minima</td>
                                  <td>$massima</td>
                                  <td>$data</td>
                                </tr>";
                      }

                      echo "</table>";
              }
              else{
                echo "Nessun risultato trovato.";
              }

              // Chiudo la connessione al database
              closeconnection($conn);
          ?>
      </div>
      <?php include './footer.php'; ?>
  </body>
  </html>
