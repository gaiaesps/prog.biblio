<?php
require_once './config.php';
require_once './database/database.php';
?>
  <!DOCTYPE html>
  <html lang="it">
  <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" type="text/css" href="./styles/style.css">
      <title>Lista Comuni</title>
      <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
                  }

                  .container {
                      max-width: 800px;
                      margin: 0 auto;
                      padding: 20px;
                  }

                  table {
                      width: 100%;
                      border-collapse: collapse;
                      margin-bottom: 20px;
                  }

                  table th,
                  table td {
                      padding: 10px;
                      text-align: left;
                      border-bottom: 1px solid #ddd;
                  }

                  table th {
                      background-color: #f2f2f2;
                  }

                  h1 {
                      text-align: center;
                  }
          .link-column {
              text-align: center;
          }

          .link-column a {
              display: inline-block;
              padding: 5px 10px;
              background-color: #3498db;
              color: #fff;
              text-decoration: none;
              border-radius: 3px;
          }
      </style>
  </head>
  <body>
      <div class="container">
          <h1>Comuni trovati</h1>
          <center><a href="./HomePage.php" class="btn">BACK TO HOME</a></center>
          <form method='POST' action=''>
           <input type='text' name='comune' placeholder="cerca comune" />
           <input type='submit' class='btn'  value='CERCA' />
          </form>
          <?php
              // Apro la connessione al database
              $conn = openconnection();

              if(isset($_POST["id_delete"]) && $_SERVER['REQUEST_METHOD'] === 'POST'){
                $id_to_delete=$_POST['id_delete'];
                $name_id=$_POST['name_id'];
                $sql1 = "DELETE FROM comuni WHERE Id = '$id_to_delete'";
                $result1 = $conn->query($sql1);

                $sql2 = "DELETE FROM temperature WHERE ID_Comune = '$id_to_delete'";
                $result2 = $conn->query($sql2);

                if($result1 === true && $result2 === true){
                  $message="Il comune $name_id è stato eliminato dal database";
                }
                else{
                  $message="non è stato possibile eliminare il comune $name_id";
                }
              }

              if(isset($message)){
                echo "$message";
              }

              if(isset($_POST["comune"]) && $_SERVER['REQUEST_METHOD'] === 'POST'){
                $comune=$_POST['comune'];
                $sql="SELECT * FROM comuni c WHERE c.Nome='$comune'";
              }
              else{
                $sql="SELECT * FROM comuni";
              }

              $result = $conn->query($sql);
              if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>Nome</th>
                            <th>Longitudine</th>
                            <th>Latitudine</th>
                            <th>Action</th>
                        </tr>";

                        while ($row = $result->fetch_assoc()) {
                            $nome = $row["Nome"];
                            $long=$row["Longitudine"];
                            $lat=$row["Latitudine"];
                            $id=$row["Id"];
                            echo "<tr>
                                    <td>$nome</td>
                                    <td>$long</td>
                                    <td>$lat</td>
                                    <td>
                                    <form method='POST' action=''>
                                     <input type='hidden' name='id_delete' value='$id' />
                                     <input type='hidden' name='name_id' value='$nome' />
                                     <input type='submit' class='btn'  value='DELETE' />
                                    </form>
                                    </td>
                                  </tr>";
                        }

                        echo "</table>";
              }
              else{
                echo "Nessun risultato trovato.";
              }
              // Chiudo la connessione al database
              closeconnection($conn);
          ?>
      </div>
      <?php include './footer.php'; ?>
  </body>
  </html>
