<?php
require_once './database/database.php';
require_once("./config.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>HomePage</title>
    <link rel="stylesheet" type="text/css" href="./styles/style.css">
</head>
<body>
    <?php
    include './header.php';
    ?>

    <section class="hero">
        <div class="hero-content">
            <h1>Benvenuti nel nostro sito</h1>
            <a href="servizi.html" class="btn">Scopri di più</a>
        </div>
    </section>

    <section class="description">
        <div class="container">
            <h2>Chi siamo</h2>
            <p>Descrizione</p>
        </div>
    </section>

    <div class="buttons">
      <form action="./regioni.php" method="get">
      <div class="button-container">
        <?php
    // Apro la connessione
    $myconnection = openconnection();

    // Definisco la query
    $sql = "SELECT Id,Nome FROM areeterritoriali";

    // Eseguo la query ed estraggo la resultset
    $result = $myconnection->query($sql);
    if ($result->num_rows > 0) {
        // Verifico se ottengo dei risultati (in caso contrario riporto un errore)
        while ($row = $result->fetch_assoc()) {
            // Valorizzo id area
            $id_area = $row["Id"];
            $nome = strtoupper($row["Nome"]);
            echo "<button type='submit' name='id' value='$id_area' class='btn'>$nome</button>";
        }
    } else {
        echo "Server error";
    }
    //Chiudo la connessione
    closeconnection($myconnection);
?>

      </div>
  </form>
    </div>

    <?php include './footer.php'; ?>
</body>
</html>
