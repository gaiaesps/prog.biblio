<?php
require_once './config.php';
require_once './database/database.php';
?>
  <!DOCTYPE html>
  <html lang="it">
  <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" type="text/css" href="./styles/style.css">
      <title>Province</title>
      <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
                  }

                  .container {
                      max-width: 800px;
                      margin: 0 auto;
                      padding: 20px;
                  }

                  table {
                      width: 100%;
                      border-collapse: collapse;
                      margin-bottom: 20px;
                  }

                  table th,
                  table td {
                      padding: 10px;
                      text-align: left;
                      border-bottom: 1px solid #ddd;
                  }

                  table th {
                      background-color: #f2f2f2;
                  }

                  h1 {
                      text-align: center;
                  }
          .link-column {
              text-align: center;
          }

          .link-column a {
              display: inline-block;
              padding: 5px 10px;
              background-color: #3498db;
              color: #fff;
              text-decoration: none;
              border-radius: 3px;
          }
      </style>
  </head>
  <body>
      <div class="container">
          <h1>Province trovate</h1>
          <center><a href="./HomePage.php" class="btn">BACK TO HOME</a></center>
          <?php
              // Apro la connessione al database
              $conn = openconnection();

              // Controllo se è stato ricevuto un ID in GET
              if (isset($_GET['id'])) {
                  // Prendo l'ID dalla query in GET
                  $id = $_GET['id'];

                  // Preparo la query
                  $sql = "SELECT Id,Nome FROM province WHERE ID_Regione = '$id'";

                  // Eseguo la query
                  $result = $conn->query($sql);

                  if ($result->num_rows > 0) {
                      echo "<table>
                              <tr>
                                  <th>Nome</th>
                                  <th>Azione</th>
                              </tr>";

                      // Itero sui risultati della query
                      while ($row = $result->fetch_assoc()) {
                          $nome = $row["Nome"];
                          $id_pro=$row["Id"];
                          echo "<tr>
                                  <td>$nome</td>
                                  <td class='link-column'>
                                      <a href='comuni.php?id=$id_pro'>Dettagli</a>
                                  </td>
                                </tr>";
                      }

                      echo "</table>";
                  } else {
                      echo "Nessun risultato trovato.";
                  }
              } else {
                  echo "ID non specificato.";
              }

              // Chiudo la connessione al database
              closeconnection($conn);
          ?>
      </div>
      <?php include './footer.php'; ?>
  </body>
  </html>
